//Yael Moreno
public class SpaceCraft {
	private String name;
	private int position;
	private int move;
	private int probability;
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setPosition(int position) {
		this.position = position;
	}
	
	public int getPosition() {
		return position;
	}
	
	public void setProb(int prob) {
		probability = prob;
	}
	
	public int getProb() {
		return probability;
	}
	
	public void setMove(int[]mov, int[]proba) {
		if (probability <= proba[0]) {
			this.move = mov[0];
		} else if (probability <= proba[1]) {
			this.move = mov[1];
		} else if (probability <= proba[2]) {
			this.move = mov[2];
		} else if (probability <= proba[3]) {
			this.move = mov[3];
		}
	}
	
	public int getMove() {
		return move;
	}
	
}
