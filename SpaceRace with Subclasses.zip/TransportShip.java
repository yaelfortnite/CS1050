//Yael Moreno
public class TransportShip extends SpaceCraft{
	private int passengers;
	private int boost;
	
	public void setPassengers(int passengers) {
		this.passengers = passengers;
	}
	
	public int getPassengers () {
		return passengers;
	}
	
	public void setBoost(int boost) {
		this.boost = boost;
	}
	
	public int getBoost() {
		return boost;
	}
	
	public void setMove(int[]mov, int[]proba) {
		if (passengers == 0) {
			System.out.println("No more passengers for " +
					getName() + "! Permanent boost added!");
			passengers = -99;
		}
		if (passengers > 0) {
			if (getProb() < 3) {
				passengers -=1;
				System.out.println("The " + getName() + 
						" has dropped off a passenger! There"
						+ " are " + getPassengers() + " left!");
			} else {
				super.setMove(mov, proba);
			}
		}
		if (passengers <= 0) {
			setPosition(getPosition() + getBoost());
			super.setMove(mov, proba);
		}
	}
	
	
	
}
