//Yael Moreno
public class CaptainShip extends SpaceCraft{
	private int turnCount;
	private int turboSpeed;

	
	public void setTurnCount(int turnCount){
		this.turnCount = turnCount;
	}
	
	public int getTurnCount() {
		return turnCount;
	}
	
	public void setTurboSpeed(int turboSpeed) {
		this.turboSpeed = turboSpeed;
	}
	
	public int getTurboSpeed() {
		return turboSpeed;
	}
	
	public void setMove(int[]mov, int[]proba) {
		super.setMove(mov, proba);
		if (turnCount %6 == 0){
			setPosition(getPosition() + turboSpeed);
			System.out.println(getName() + " activated turbo!");
		}
	}
		
}
