// Yael Moreno
import java.util.*;

public class SpaceRace2 {

	public static void main(String[] args) {
		Random random = new Random();
		
		//The first spacecraft, Arwing, made with the class.
		SpaceCraft arwing = new SpaceCraft();
		arwing.setName("Arwing");
		arwing.setPosition(1);
		int[] arwingMovement = {0,1,7,-4};
		int[] arwingProbability = {1,3,7,11};
	
		//The second spacecraft, Blue Falcon, also made with the class.
		SpaceCraft blueFalcon = new SpaceCraft();
		blueFalcon.setName("Blue Falcon");
		blueFalcon.setPosition(1);
		int[] blueFalconMovement = {3,5,1,1};
		int[] blueFalconProbability = {2,5,10,10};
		
		// Just a little flare to the introduction of the race, nothing special.
		System.out.println("3... 2... 1... Go!");
		displayRaceTrack(blueFalcon.getPosition(), arwing.getPosition());
		
		while(true) {
			// They set the probability first, then choose a movement based on the 
			// probability, and then update the position.
			arwing.setProb(random.nextInt(10)+1);
			blueFalcon.setProb(random.nextInt(10)+1);
			arwing.setMove(arwingMovement, arwingProbability);
			blueFalcon.setMove(blueFalconMovement, blueFalconProbability);
			arwing.setPosition(arwing.getPosition()+ arwing.getMove());
			blueFalcon.setPosition(blueFalcon.getPosition() + blueFalcon.getMove());
			
			// These will help just in case they go out of bounds
			if (arwing.getPosition() < 1) {
				arwing.setPosition(1);
			} else if (arwing.getPosition() > 70) {
				arwing.setPosition(70);
			}
				
			if (blueFalcon.getPosition() < 1) {
				blueFalcon.setPosition(1);
			} else if (blueFalcon.getPosition() > 70) {
					blueFalcon.setPosition(70);
				}
			///////////////////////////////////////////////////////
			
			// Winning condition. If one of the spacecrafts get to the finish
			// line, the program will end and some text will appear.
			if (blueFalcon.getPosition() == 70 || arwing.getPosition() == 70) {
				if (blueFalcon.getPosition() == 70 && arwing.getPosition() == 70) {
				System.out.println(" ");
				System.out.println("!!!!! ");
				displayRaceTrack(blueFalcon.getPosition(), arwing.getPosition());
				System.out.println("Tie!");
				}else if (blueFalcon.getPosition() == 70) {
				System.out.println(" ");
				System.out.println("!!!!! ");
				displayRaceTrack(blueFalcon.getPosition(), arwing.getPosition());
				System.out.println(blueFalcon.getName() + " wins the race!");
				} else if (arwing.getPosition() == 70) {
				System.out.println(" ");
				System.out.println("!!!!! ");
				displayRaceTrack(blueFalcon.getPosition(), arwing.getPosition());
				System.out.println(arwing.getName() + " wins the race!");
				}
				break;
			}
			
			// The user can press a key to continue the race
			Scanner key = new Scanner(System.in);
			System.out.println("Press any key to continue ");
			key.nextLine();
			
			// The race track updates each time the user presses a key.
			displayRaceTrack(blueFalcon.getPosition(), arwing.getPosition());
			
			// Triggers if both ships are in the same position.
			if (blueFalcon.getPosition() == arwing.getPosition()) {
				System.out.println("BUMP!!!");
			}
		}
	}
	
	// Prints the race track
		public static void displayRaceTrack (int blueFalconPosition, int arwingPosition) {
			StringBuilder raceTrack = new StringBuilder("Start |");
			for (int i = 1; i <=70; i++) {
				if (i == blueFalconPosition && i == arwingPosition) {
					raceTrack.append("@");
				} else if (i == arwingPosition) {
					raceTrack.append("A");
				} else if (i == blueFalconPosition) {
					raceTrack.append("B");
				} else {
					raceTrack.append("-");
				}
			}
			raceTrack.append("| End");
			System.out.println(raceTrack);
		}
}